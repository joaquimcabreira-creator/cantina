'use strict';

/* ------------------------------------------------------------------ */
/* Utilidades                                                          */
/* ------------------------------------------------------------------ */

const $ = (seletor, raiz = document) => raiz.querySelector(seletor);
const $$ = (seletor, raiz = document) => [...raiz.querySelectorAll(seletor)];

const UNIDADES = ['un', 'fatia', 'porção', 'pote', 'copo', 'garrafa', 'lata', 'pacote'];
const MOTIVOS = [
  'Venda no intervalo',
  'Venda no recreio',
  'Compra de fornecedor',
  'Reposição de estoque',
  'Perda ou vencimento',
  'Ajuste de contagem',
];

const moedaFmt = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const numeroFmt = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 3 });

const moeda = (valor) => moedaFmt.format(Number(valor) || 0);
const numero = (valor) => numeroFmt.format(Number(valor) || 0);

const state = {
  view: 'painel',
  produtos: [],
  movimentacoes: [],
  resumo: {},
  categorias: [],
  busca: '',
  categoria: '',
  status: '',
  tipo: '',
  pin: localStorage.getItem('cantina.pin') || '',
};

const els = {
  stats: $('#stats'),
  alertList: $('#alertList'),
  recentList: $('#recentList'),
  produtosList: $('#produtosList'),
  produtosInfo: $('#produtosInfo'),
  movsList: $('#movsList'),
  movInfo: $('#movInfo'),
  busca: $('#busca'),
  filtroCategoria: $('#filtroCategoria'),
  filtroStatus: $('#filtroStatus'),
  filtroTipo: $('#filtroTipo'),
  pageTitle: $('#pageTitle'),
  pageEyebrow: $('#pageEyebrow'),
  dateChip: $('#dateChip'),
  btnAtualizar: $('#btnAtualizar'),
  btnPin: $('#btnPin'),
  dialog: $('#dialog'),
  pinDialog: $('#pinDialog'),
  toasts: $('#toasts'),
};

function esc(valor) {
  return String(valor ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  }[c]));
}

function icon(nome) {
  return `<svg class="ic" aria-hidden="true"><use href="#i-${nome}"></use></svg>`;
}

function normalizar(texto) {
  return String(texto || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

function statusProduto(produto) {
  if (produto.estoque <= 0) return { chave: 'falta', rotulo: 'Em falta' };
  if (produto.estoque <= produto.estoqueMinimo) return { chave: 'baixo', rotulo: 'Estoque baixo' };
  return { chave: 'ok', rotulo: 'Disponível' };
}

function unidadeFormatada(quantidade, unidade) {
  if (Number(quantidade) === 1) return unidade;
  const plurais = {
    fatia: 'fatias',
    'porção': 'porções',
    pote: 'potes',
    copo: 'copos',
    garrafa: 'garrafas',
    lata: 'latas',
    pacote: 'pacotes',
  };
  return plurais[unidade] || unidade;
}

function avatar(produto) {
  const conectores = new Set(['de', 'da', 'do', 'das', 'dos', 'com', 'ao', 'a', 'e']);
  const palavras = String(produto.nome || '')
    .trim()
    .split(/\s+/)
    .filter((palavra) => /^[A-Za-zÀ-ÿ]/.test(palavra) && !conectores.has(palavra.toLowerCase()));

  const iniciais = (palavras.length ? palavras : ['?'])
    .slice(0, 2)
    .map((palavra) => palavra[0])
    .join('')
    .toUpperCase();

  const paleta = [...String(produto.categoria || 'x')].reduce((soma, letra) => soma + letra.charCodeAt(0), 0) % 5;
  return `<span class="avatar c${paleta}">${esc(iniciais)}</span>`;
}

function mesmoDia(a, b) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function quando(iso) {
  const data = new Date(iso);
  if (Number.isNaN(data.getTime())) return '';
  const agora = new Date();
  const ontem = new Date();
  ontem.setDate(agora.getDate() - 1);
  const hora = data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  if (mesmoDia(data, agora)) return `Hoje, ${hora}`;
  if (mesmoDia(data, ontem)) return `Ontem, ${hora}`;
  return `${data.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}, ${hora}`;
}

function vazio(icone, titulo, texto) {
  return `<div class="empty">${icon(icone)}<strong>${esc(titulo)}</strong><p>${esc(texto)}</p></div>`;
}

function toast(mensagem, tipo = 'ok') {
  const el = document.createElement('div');
  el.className = `toast ${tipo}`;
  el.innerHTML = `${icon(tipo === 'erro' ? 'alert' : 'check')}<span>${esc(mensagem)}</span>`;
  els.toasts.appendChild(el);
  setTimeout(() => {
    el.classList.add('saindo');
    setTimeout(() => el.remove(), 240);
  }, 3400);
}

/* ------------------------------------------------------------------ */
/* Comunicação com o servidor                                          */
/* ------------------------------------------------------------------ */

async function api(caminho, opcoes = {}) {
  const { method = 'GET', body, auth = false, tentativa = 0 } = opcoes;
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (auth && state.pin) headers['x-cantina-pin'] = state.pin;

  let resposta;
  try {
    resposta = await fetch(caminho, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new Error('Não foi possível falar com o servidor. Verifique a conexão.');
  }

  let dados = null;
  try {
    dados = await resposta.json();
  } catch {
    /* resposta sem corpo */
  }

  if (resposta.status === 401 && tentativa === 0) {
    const liberado = await solicitarPin('alterar os dados da cantina');
    if (liberado) return api(caminho, { method, body, auth, tentativa: 1 });
    throw new Error('Ação cancelada: é necessário informar o PIN.');
  }

  if (!resposta.ok) {
    throw new Error((dados && dados.erro) || `Erro ${resposta.status} ao acessar o servidor.`);
  }

  return dados;
}

async function carregar() {
  const dados = await api('/api/estado?limite=300');
  state.produtos = dados.produtos || [];
  state.movimentacoes = dados.movimentacoes || [];
  state.resumo = dados.resumo || {};
  state.categorias = dados.categorias || [];
  renderTudo();
}

/* ------------------------------------------------------------------ */
/* Diálogos                                                            */
/* ------------------------------------------------------------------ */

function montarDialog(elemento, html, setup) {
  return new Promise((resolve) => {
    if (elemento.open) elemento.close();
    elemento.innerHTML = html;
    elemento.showModal();

    let finalizado = false;

    const finalizar = (valor) => {
      if (finalizado) return;
      finalizado = true;
      elemento.removeEventListener('close', aoFechar);
      resolve(valor);
      if (elemento.open) elemento.close();
    };

    const aoFechar = () => {
      if (finalizado) return;
      finalizado = true;
      resolve(undefined);
    };

    elemento.addEventListener('close', aoFechar);
    $$('[data-close]', elemento).forEach((botao) => {
      botao.addEventListener('click', () => finalizar(undefined));
    });

    if (setup) {
      setup({ raiz: elemento, finalizar, form: $('form', elemento) });
    }
  });
}

function openDialog(html, setup) {
  return montarDialog(els.dialog, html, setup);
}

function openPinDialog(html, setup) {
  return montarDialog(els.pinDialog, html, setup);
}

function solicitarPin(motivo) {
  const html = `
    <div class="dialog-card">
      <button class="dialog-x" type="button" data-close aria-label="Fechar">&times;</button>
      <h2 id="dialogTitle">Acesso da cantina</h2>
      <p class="muted">Informe o PIN para ${esc(motivo)}.</p>
      <form>
        <label class="field">
          <span>PIN de acesso</span>
          <input id="pinInput" type="password" inputmode="numeric" autocomplete="current-password" placeholder="••••" maxlength="20" />
        </label>
        <p class="form-error" id="pinErro"></p>
        <div class="dialog-actions">
          <button class="btn ghost" type="button" data-close>Cancelar</button>
          <button class="btn primary" type="submit">Entrar</button>
        </div>
      </form>
    </div>`;

  return openPinDialog(html, ({ raiz, finalizar, form }) => {
    const campo = $('#pinInput', raiz);
    const erro = $('#pinErro', raiz);
    setTimeout(() => campo.focus(), 40);

    form.addEventListener('submit', async (evento) => {
      evento.preventDefault();
      const pin = campo.value.trim();
      if (!pin) {
        erro.textContent = 'Digite o PIN da cantina.';
        return;
      }
      const botao = $('button[type="submit"]', form);
      botao.disabled = true;
      botao.textContent = 'Verificando...';
      try {
        const resposta = await fetch('/api/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin }),
        });
        if (!resposta.ok) throw new Error();
        state.pin = pin;
        localStorage.setItem('cantina.pin', pin);
        finalizar(true);
        toast('Acesso liberado.');
      } catch {
        erro.textContent = 'PIN incorreto. Tente novamente.';
        campo.select();
        botao.disabled = false;
        botao.textContent = 'Entrar';
      }
    });
  });
}

async function abrirAcessoPin() {
  const temPin = Boolean(state.pin);
  await openDialog(`
    <div class="dialog-card">
      <button class="dialog-x" type="button" data-close aria-label="Fechar">&times;</button>
      <h2 id="dialogTitle">Acesso da cantina</h2>
      <p class="muted">O PIN protege o cadastro de produtos e as movimentações de estoque. Ele fica salvo somente neste aparelho.</p>
      <div class="pin-status ${temPin ? 'ok' : 'off'}">
        ${icon(temPin ? 'check' : 'lock')}
        ${temPin ? 'Este aparelho está autorizado' : 'Nenhum PIN salvo neste aparelho'}
      </div>
      <div class="dialog-actions">
        ${temPin ? '<button class="btn ghost" type="button" id="esquecerPin">Esquecer PIN</button>' : ''}
        <button class="btn primary" type="button" id="definirPin">${temPin ? 'Trocar PIN' : 'Informar PIN'}</button>
      </div>
    </div>`, ({ raiz, finalizar }) => {
    $('#definirPin', raiz).addEventListener('click', async () => {
      finalizar();
      const liberado = await solicitarPin('autorizar este aparelho');
      if (liberado) toast('PIN salvo neste aparelho.');
    });

    const esquecer = $('#esquecerPin', raiz);
    if (esquecer) {
      esquecer.addEventListener('click', () => {
        state.pin = '';
        localStorage.removeItem('cantina.pin');
        finalizar();
        toast('PIN removido deste aparelho.');
      });
    }
  });
}

/* ------------------------------------------------------------------ */
/* Renderização                                                        */
/* ------------------------------------------------------------------ */

function renderTudo() {
  renderStats();
  renderAlertas();
  renderRecentes();
  preencherCategorias();
  renderProdutos();
  renderMovs();
}

function renderStats() {
  const r = state.resumo;
  const alertas = Number(r.alertas) || 0;
  const cards = [
    {
      icone: 'box',
      tom: 'verde',
      rotulo: 'Produtos cadastrados',
      valor: numero(r.totalProdutos),
      nota: `${state.categorias.length} categoria${state.categorias.length === 1 ? '' : 's'}`,
    },
    {
      icone: 'alert',
      tom: alertas > 0 ? 'vermelho' : 'verde',
      rotulo: 'Estoque em alerta',
      valor: numero(alertas),
      nota: `${numero(r.zerados)} em falta · ${numero(r.baixos)} baixos`,
    },
    {
      icone: 'money',
      tom: 'ambar',
      rotulo: 'Valor do estoque',
      valor: moeda(r.valorEstoque),
      nota: 'A preço de venda',
    },
    {
      icone: 'trend',
      tom: 'neutro',
      rotulo: 'Saídas hoje',
      valor: numero(r.saidasHoje),
      nota: `≈ ${moeda(r.receitaHoje)} em vendas`,
    },
  ];

  els.stats.innerHTML = cards.map((card) => `
    <article class="stat">
      <span class="stat-icone ${card.tom}">${icon(card.icone)}</span>
      <div>
        <span class="stat-rotulo">${esc(card.rotulo)}</span>
        <strong class="stat-valor">${card.valor}</strong>
        <span class="stat-nota">${esc(card.nota)}</span>
      </div>
    </article>`).join('');
}

function renderAlertas() {
  const alertas = state.produtos
    .filter((p) => p.estoque <= p.estoqueMinimo)
    .sort((a, b) => a.estoque - b.estoque || a.nome.localeCompare(b.nome, 'pt-BR'))
    .slice(0, 6);

  if (!alertas.length) {
    els.alertList.innerHTML = vazio('check', 'Tudo em ordem', 'Nenhum produto está abaixo do estoque mínimo.');
    return;
  }

  els.alertList.innerHTML = alertas.map((p) => {
    const status = statusProduto(p);
    return `
      <div class="alert-row">
        ${avatar(p)}
        <div class="alert-info">
          <strong>${esc(p.nome)}</strong>
          <span>Estoque: ${numero(p.estoque)} ${esc(unidadeFormatada(p.estoque, p.unidade))} · mínimo ${numero(p.estoqueMinimo)}</span>
        </div>
        <span class="badge ${status.chave}">${status.rotulo}</span>
        <button class="btn soft tiny" type="button" data-action="repor" data-id="${p.id}">Repor</button>
      </div>`;
  }).join('');
}

function linhaMovimentacao(mov) {
  const nomes = { entrada: 'Entrada', saida: 'Saída', ajuste: 'Ajuste' };
  const icones = { entrada: 'arrow-down', saida: 'arrow-up', ajuste: 'refresh' };
  const sinal = mov.tipo === 'entrada' ? '+' : mov.tipo === 'saida' ? '−' : '= ';
  const detalhe = `${mov.motivo || nomes[mov.tipo]} · ${quando(mov.data)}`;

  return `
    <div class="mov-row">
      <span class="mov-icone ${mov.tipo}">${icon(icones[mov.tipo] || 'refresh')}</span>
      <div class="mov-info">
        <strong>${esc(mov.produtoNome)}</strong>
        <span>${esc(detalhe)} · estoque: ${numero(mov.estoqueApos)} ${esc(unidadeFormatada(mov.estoqueApos, mov.unidade || ''))}</span>
      </div>
      <span class="mov-qtd ${mov.tipo}">${sinal}${numero(mov.quantidade)}</span>
    </div>`;
}

function renderRecentes() {
  const recentes = state.movimentacoes.slice(0, 6);
  if (!recentes.length) {
    els.recentList.innerHTML = vazio('history', 'Sem movimentações', 'As entradas e saídas de hoje aparecerão aqui.');
    return;
  }
  els.recentList.innerHTML = recentes.map(linhaMovimentacao).join('');
}

function preencherCategorias() {
  const opcoes = state.categorias
    .map((categoria) => `<option value="${esc(categoria)}">${esc(categoria)}</option>`)
    .join('');
  els.filtroCategoria.innerHTML = `<option value="">Todas as categorias</option>${opcoes}`;

  if (state.categoria && !state.categorias.includes(state.categoria)) {
    state.categoria = '';
  }
  els.filtroCategoria.value = state.categoria;
}

function produtosFiltrados() {
  const termo = normalizar(state.busca);
  return state.produtos.filter((p) => {
    if (termo && !normalizar(`${p.nome} ${p.categoria}`).includes(termo)) return false;
    if (state.categoria && p.categoria !== state.categoria) return false;

    if (state.status) {
      const chave = statusProduto(p).chave;
      if (state.status === 'alerta') {
        if (chave !== 'baixo' && chave !== 'falta') return false;
      } else if (chave !== state.status) {
        return false;
      }
    }

    return true;
  });
}

function renderProdutos() {
  const lista = produtosFiltrados();
  els.produtosInfo.textContent = `${numero(lista.length)} de ${numero(state.produtos.length)} produtos`;

  if (!lista.length) {
    const texto = state.produtos.length
      ? 'Ajuste a busca ou os filtros para encontrar o produto.'
      : 'Cadastre o primeiro produto da cantina para começar.';
    els.produtosList.innerHTML = vazio('box', 'Nenhum produto encontrado', texto);
    return;
  }

  els.produtosList.innerHTML = lista.map((p) => {
    const status = statusProduto(p);
    const referencia = Math.max(p.estoqueMinimo * 3, 1);
    const percentual = Math.max(0, Math.min(100, Math.round((p.estoque / referencia) * 100)));

    return `
      <div class="prod-row prod-grid">
        <div class="prod-main">
          ${avatar(p)}
          <div class="prod-id">
            <span class="prod-name">${esc(p.nome)}</span>
            <span class="prod-meta">${esc(p.categoria)} · ${esc(p.unidade)}</span>
          </div>
        </div>

        <div class="prod-preco">${moeda(p.preco)}</div>

        <div class="prod-estoque">
          <div class="estoque-top"><strong>${numero(p.estoque)}</strong> <span class="muted">${esc(unidadeFormatada(p.estoque, p.unidade))}</span></div>
          <div class="bar"><span class="bar-fill ${status.chave}" style="width:${percentual}%"></span></div>
          <span class="estoque-min">mín. ${numero(p.estoqueMinimo)}</span>
        </div>

        <div class="prod-status"><span class="badge ${status.chave}">${status.rotulo}</span></div>

        <div class="prod-actions">
          <button class="icon-btn sm" type="button" data-action="entrada" data-id="${p.id}" title="Registrar entrada" aria-label="Registrar entrada de ${esc(p.nome)}">${icon('arrow-down')}</button>
          <button class="icon-btn sm" type="button" data-action="saida" data-id="${p.id}" title="Registrar saída" aria-label="Registrar saída de ${esc(p.nome)}">${icon('arrow-up')}</button>
          <button class="icon-btn sm" type="button" data-action="editar" data-id="${p.id}" title="Editar produto" aria-label="Editar ${esc(p.nome)}">${icon('edit')}</button>
          <button class="icon-btn sm danger" type="button" data-action="excluir" data-id="${p.id}" title="Excluir produto" aria-label="Excluir ${esc(p.nome)}">${icon('trash')}</button>
        </div>
      </div>`;
  }).join('');
}

function renderMovs() {
  const lista = state.movimentacoes.filter((m) => !state.tipo || m.tipo === state.tipo);
  els.movInfo.textContent = `${numero(lista.length)} registro${lista.length === 1 ? '' : 's'} · até 300 mais recentes`;

  if (!lista.length) {
    els.movsList.innerHTML = vazio('history', 'Nenhuma movimentação', 'Registre entradas, saídas e ajustes de estoque.');
    return;
  }

  els.movsList.innerHTML = lista.map(linhaMovimentacao).join('');
}

/* ------------------------------------------------------------------ */
/* Formulários                                                         */
/* ------------------------------------------------------------------ */

function numeroDoCampo(valor) {
  const texto = String(valor ?? '').trim();
  if (!texto) return NaN;
  if (texto.includes(',')) return Number(texto.replace(/\./g, '').replace(',', '.'));
  return Number(texto);
}

function abrirProdutoModal(produto) {
  const editando = Boolean(produto);
  const p = produto || { nome: '', categoria: '', preco: '', unidade: 'un', estoqueMinimo: 5, estoque: 0 };
  const categorias = [...new Set([...state.categorias, p.categoria].filter(Boolean))];
  const unidades = UNIDADES
    .map((unidade) => `<option value="${esc(unidade)}" ${unidade === p.unidade ? 'selected' : ''}>${esc(unidade)}</option>`)
    .join('');

  const html = `
    <div class="dialog-card">
      <button class="dialog-x" type="button" data-close aria-label="Fechar">&times;</button>
      <h2 id="dialogTitle">${editando ? 'Editar produto' : 'Novo produto'}</h2>
      <p class="muted">${editando ? 'A quantidade em estoque é alterada pelas movimentações.' : 'Cadastre um item do cardápio com preço, unidade e estoque mínimo.'}</p>
      <form>
        <div class="form-grid">
          <label class="field span2">
            <span>Nome do produto</span>
            <input name="nome" required maxlength="80" value="${esc(p.nome)}" placeholder="Ex.: Pão de queijo" />
          </label>

          <label class="field">
            <span>Categoria</span>
            <input name="categoria" list="listaCategorias" maxlength="40" value="${esc(p.categoria)}" placeholder="Salgados" />
            <datalist id="listaCategorias">
              ${categorias.map((categoria) => `<option value="${esc(categoria)}"></option>`).join('')}
            </datalist>
          </label>

          <label class="field">
            <span>Unidade</span>
            <select name="unidade">${unidades}</select>
          </label>

          <label class="field">
            <span>Preço de venda (R$)</span>
            <input name="preco" type="number" min="0" step="0.01" inputmode="decimal" required value="${esc(p.preco)}" placeholder="0,00" />
          </label>

          ${editando ? '' : `
          <label class="field">
            <span>Estoque inicial</span>
            <input name="estoque" type="number" min="0" step="1" inputmode="numeric" value="0" />
          </label>`}

          <label class="field">
            <span>Estoque mínimo</span>
            <input name="estoqueMinimo" type="number" min="0" step="1" inputmode="numeric" value="${esc(p.estoqueMinimo)}" />
            <span class="estoque-min">Avisamos quando o estoque chegar neste valor.</span>
          </label>

          <p class="form-error span2"></p>

          <div class="dialog-actions span2">
            <button class="btn ghost" type="button" data-close>Cancelar</button>
            <button class="btn primary" type="submit">${editando ? 'Salvar alterações' : 'Cadastrar produto'}</button>
          </div>
        </div>
      </form>
    </div>`;

  openDialog(html, ({ raiz, finalizar, form }) => {
    const erro = $('.form-error', raiz);
    setTimeout(() => $('[name="nome"]', form).focus(), 40);

    form.addEventListener('submit', async (evento) => {
      evento.preventDefault();
      const dados = new FormData(form);
      const preco = numeroDoCampo(dados.get('preco'));
      const estoqueMinimo = numeroDoCampo(dados.get('estoqueMinimo'));
      const estoque = numeroDoCampo(dados.get('estoque'));

      const corpo = {
        nome: String(dados.get('nome') || '').trim(),
        categoria: String(dados.get('categoria') || '').trim() || 'Geral',
        unidade: String(dados.get('unidade') || 'un'),
        preco,
        estoqueMinimo: Number.isFinite(estoqueMinimo) ? estoqueMinimo : 0,
      };

      if (!corpo.nome) {
        erro.textContent = 'Informe o nome do produto.';
        return;
      }
      if (!Number.isFinite(preco) || preco < 0) {
        erro.textContent = 'Informe um preço válido.';
        return;
      }
      if (!editando) {
        corpo.estoque = Number.isFinite(estoque) && estoque > 0 ? estoque : 0;
      }

      erro.textContent = '';
      const botao = $('button[type="submit"]', form);
      const rotulo = botao.textContent;
      botao.disabled = true;
      botao.textContent = 'Salvando...';

      try {
        if (editando) {
          await api(`/api/produtos/${p.id}`, { method: 'PUT', auth: true, body: corpo });
        } else {
          await api('/api/produtos', { method: 'POST', auth: true, body: corpo });
        }
        finalizar(true);
        await carregar();
        toast(editando ? 'Produto atualizado.' : 'Produto cadastrado.');
      } catch (err) {
        erro.textContent = err.message;
        botao.disabled = false;
        botao.textContent = rotulo;
      }
    });
  });
}

function abrirMovimentacaoModal(produto, tipoInicial = 'saida') {
  const p = produto;
  const status = statusProduto(p);
  const motivos = MOTIVOS.map((motivo) => `<option value="${esc(motivo)}"></option>`).join('');

  const html = `
    <div class="dialog-card">
      <button class="dialog-x" type="button" data-close aria-label="Fechar">&times;</button>
      <h2 id="dialogTitle">Movimentar estoque</h2>
      <p class="muted">Registre uma entrada, uma saída ou um ajuste de contagem.</p>

      <div class="mov-produto">
        ${avatar(p)}
        <div>
          <strong>${esc(p.nome)}</strong>
          <span>Estoque atual: <b>${numero(p.estoque)} ${esc(unidadeFormatada(p.estoque, p.unidade))}</b> · ${status.rotulo}</span>
        </div>
      </div>

      <form>
        <div class="segmented">
          <button type="button" data-tipo="entrada">Entrada</button>
          <button type="button" data-tipo="saida">Saída</button>
          <button type="button" data-tipo="ajuste">Ajuste</button>
        </div>

        <div class="qty-field">
          <span id="rotuloQtd">Quantidade</span>
          <div class="stepper">
            <button type="button" data-step="-1" aria-label="Diminuir">−</button>
            <input id="qtd" type="number" min="1" step="1" value="1" inputmode="numeric" />
            <button type="button" data-step="1" aria-label="Aumentar">+</button>
          </div>
        </div>

        <label class="field">
          <span>Motivo (opcional)</span>
          <input name="motivo" list="listaMotivos" maxlength="120" placeholder="Ex.: venda no intervalo" />
          <datalist id="listaMotivos">${motivos}</datalist>
        </label>

        <p class="previa" id="previa"></p>
        <p class="form-error"></p>

        <div class="dialog-actions">
          <button class="btn ghost" type="button" data-close>Cancelar</button>
          <button class="btn primary" type="submit">Registrar</button>
        </div>
      </form>
    </div>`;

  openDialog(html, ({ raiz, finalizar, form }) => {
    let tipo = tipoInicial;
    const campoQtd = $('#qtd', raiz);
    const rotuloQtd = $('#rotuloQtd', raiz);
    const previa = $('#previa', raiz);
    const erro = $('.form-error', raiz);

    const atualizar = () => {
      $$('[data-tipo]', raiz).forEach((botao) => {
        botao.classList.toggle('active', botao.dataset.tipo === tipo);
      });

      rotuloQtd.textContent = tipo === 'ajuste'
        ? 'Novo estoque'
        : tipo === 'entrada'
          ? 'Quantidade a entrar'
          : 'Quantidade a sair';

      const quantidade = Math.max(tipo === 'ajuste' ? 0 : 1, numeroDoCampo(campoQtd.value) || 0);
      let depois = p.estoque;
      if (tipo === 'entrada') depois = p.estoque + quantidade;
      else if (tipo === 'saida') depois = Math.max(0, p.estoque - quantidade);
      else depois = quantidade;

      previa.innerHTML = `Estoque após o registro: <strong>${numero(depois)} ${esc(unidadeFormatada(depois, p.unidade))}</strong>`;
    };

    $$('[data-tipo]', raiz).forEach((botao) => {
      botao.addEventListener('click', () => {
        tipo = botao.dataset.tipo;
        campoQtd.value = tipo === 'ajuste' ? String(p.estoque) : '1';
        erro.textContent = '';
        atualizar();
      });
    });

    $$('[data-step]', raiz).forEach((botao) => {
      botao.addEventListener('click', () => {
        const passo = Number(botao.dataset.step);
        const minimo = tipo === 'ajuste' ? 0 : 1;
        const atual = Math.round(numeroDoCampo(campoQtd.value) || 0);
        campoQtd.value = String(Math.max(minimo, atual + passo));
        atualizar();
      });
    });

    campoQtd.addEventListener('input', atualizar);
    atualizar();
    setTimeout(() => campoQtd.focus(), 40);

    form.addEventListener('submit', async (evento) => {
      evento.preventDefault();
      const quantidade = numeroDoCampo(campoQtd.value);

      if (!Number.isFinite(quantidade) || quantidade < 0 || (tipo !== 'ajuste' && quantidade < 1)) {
        erro.textContent = 'Informe uma quantidade válida.';
        return;
      }
      if (tipo === 'saida' && quantidade > p.estoque) {
        erro.textContent = `Estoque insuficiente. Disponível: ${numero(p.estoque)} ${unidadeFormatada(p.estoque, p.unidade)}.`;
        return;
      }

      erro.textContent = '';
      const botao = $('button[type="submit"]', form);
      botao.disabled = true;
      botao.textContent = 'Registrando...';

      try {
        await api(`/api/produtos/${p.id}/movimentacoes`, {
          method: 'POST',
          auth: true,
          body: { tipo, quantidade, motivo: String(new FormData(form).get('motivo') || '') },
        });
        finalizar(true);
        await carregar();
        const mensagens = { entrada: 'Entrada registrada.', saida: 'Saída registrada.', ajuste: 'Estoque ajustado.' };
        toast(mensagens[tipo]);
      } catch (err) {
        erro.textContent = err.message;
        botao.disabled = false;
        botao.textContent = 'Registrar';
      }
    });
  });
}

async function excluirProduto(produto) {
  const confirmado = await openDialog(`
    <div class="dialog-card">
      <button class="dialog-x" type="button" data-close aria-label="Fechar">&times;</button>
      <h2 id="dialogTitle">Excluir produto</h2>
      <div class="pin-status off">${icon('alert')} Esta ação não pode ser desfeita</div>
      <p class="muted">O produto <strong>${esc(produto.nome)}</strong> será removido do estoque. O histórico de movimentações continua salvo.</p>
      <div class="dialog-actions">
        <button class="btn ghost" type="button" data-close>Cancelar</button>
        <button class="btn danger" type="button" id="confirmarExclusao">Excluir produto</button>
      </div>
    </div>`, ({ raiz, finalizar }) => {
    $('#confirmarExclusao', raiz).addEventListener('click', () => finalizar(true));
  });

  if (!confirmado) return;

  try {
    await api(`/api/produtos/${produto.id}`, { method: 'DELETE', auth: true });
    await carregar();
    toast('Produto excluído.');
  } catch (err) {
    toast(err.message, 'erro');
  }
}

/* ------------------------------------------------------------------ */
/* Exportação                                                          */
/* ------------------------------------------------------------------ */

function exportarCsv() {
  if (!state.produtos.length) {
    toast('Não há produtos para exportar.', 'erro');
    return;
  }

  const linhas = [['Produto', 'Categoria', 'Preço (R$)', 'Estoque', 'Unidade', 'Estoque mínimo', 'Status']];
  for (const p of state.produtos) {
    linhas.push([
      p.nome,
      p.categoria,
      Number(p.preco).toFixed(2).replace('.', ','),
      p.estoque,
      p.unidade,
      p.estoqueMinimo,
      statusProduto(p).rotulo,
    ]);
  }

  const csv = '\uFEFF' + linhas
    .map((linha) => linha.map((celula) => `"${String(celula).replace(/"/g, '""')}"`).join(';'))
    .join('\r\n');

  const arquivo = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(arquivo);
  link.download = `estoque-cantina-${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
  toast('Planilha exportada.');
}

/* ------------------------------------------------------------------ */
/* Navegação e eventos                                                 */
/* ------------------------------------------------------------------ */

const TELAS = {
  painel: { titulo: 'Visão geral', eyebrow: 'Painel' },
  produtos: { titulo: 'Produtos e estoque', eyebrow: 'Cantina' },
  movimentacoes: { titulo: 'Movimentações', eyebrow: 'Histórico' },
};

function viewDoHash() {
  const chave = location.hash.replace(/^#\/?/, '');
  return TELAS[chave] ? chave : 'painel';
}

function trocarView(view) {
  if (!TELAS[view]) return;
  state.view = view;

  $$('.view').forEach((secao) => {
    secao.hidden = secao.id !== `view-${view}`;
  });

  $$('.nav-btn').forEach((botao) => {
    botao.classList.toggle('active', botao.dataset.view === view);
  });

  if (viewDoHash() !== view) {
    const endereco = view === 'painel' ? location.pathname + location.search : `#${view}`;
    history.replaceState(null, '', endereco);
  }

  els.pageTitle.textContent = TELAS[view].titulo;
  els.pageEyebrow.textContent = TELAS[view].eyebrow;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function configurarEventos() {
  $$('.nav-btn').forEach((botao) => {
    botao.addEventListener('click', () => trocarView(botao.dataset.view));
  });

  $$('[data-goto]').forEach((botao) => {
    botao.addEventListener('click', () => trocarView(botao.dataset.goto));
  });

  els.busca.addEventListener('input', () => {
    state.busca = els.busca.value;
    renderProdutos();
  });

  els.filtroCategoria.addEventListener('change', () => {
    state.categoria = els.filtroCategoria.value;
    renderProdutos();
  });

  els.filtroStatus.addEventListener('change', () => {
    state.status = els.filtroStatus.value;
    renderProdutos();
  });

  els.filtroTipo.addEventListener('change', () => {
    state.tipo = els.filtroTipo.value;
    renderMovs();
  });

  $('#btnNovo').addEventListener('click', () => abrirProdutoModal(null));
  $('#btnExportar').addEventListener('click', exportarCsv);
  els.btnPin.addEventListener('click', abrirAcessoPin);

  els.btnAtualizar.addEventListener('click', async () => {
    els.btnAtualizar.classList.add('girando');
    try {
      await carregar();
      toast('Dados atualizados.');
    } catch (err) {
      toast(err.message, 'erro');
    } finally {
      setTimeout(() => els.btnAtualizar.classList.remove('girando'), 450);
    }
  });

  els.produtosList.addEventListener('click', (evento) => {
    const botao = evento.target.closest('[data-action]');
    if (!botao) return;
    const produto = state.produtos.find((p) => p.id === botao.dataset.id);
    if (!produto) return;

    if (botao.dataset.action === 'entrada') abrirMovimentacaoModal(produto, 'entrada');
    if (botao.dataset.action === 'saida') abrirMovimentacaoModal(produto, 'saida');
    if (botao.dataset.action === 'editar') abrirProdutoModal(produto);
    if (botao.dataset.action === 'excluir') excluirProduto(produto);
  });

  els.alertList.addEventListener('click', (evento) => {
    const botao = evento.target.closest('[data-action="repor"]');
    if (!botao) return;
    const produto = state.produtos.find((p) => p.id === botao.dataset.id);
    if (produto) abrirMovimentacaoModal(produto, 'entrada');
  });

  els.dialog.addEventListener('click', (evento) => {
    if (evento.target === els.dialog) els.dialog.close();
  });

  els.pinDialog.addEventListener('click', (evento) => {
    if (evento.target === els.pinDialog) els.pinDialog.close();
  });

  window.addEventListener('hashchange', () => trocarView(viewDoHash()));

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && !els.dialog.open && !els.pinDialog.open) carregar().catch(() => {});
  });

  setInterval(() => {
    if (document.hidden || els.dialog.open || els.pinDialog.open) return;
    carregar().catch(() => {});
  }, 25000);
}

/* ------------------------------------------------------------------ */
/* Início                                                              */
/* ------------------------------------------------------------------ */

async function iniciar() {
  const agora = new Date();
  const diaSemana = agora.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', '');
  const mes = agora.toLocaleDateString('pt-BR', { month: 'short' }).replace('.', '');
  els.dateChip.textContent = `${diaSemana.charAt(0).toUpperCase()}${diaSemana.slice(1)}, ${String(agora.getDate()).padStart(2, '0')} de ${mes}`;

  configurarEventos();
  trocarView(viewDoHash());

  try {
    await carregar();
  } catch (err) {
    toast(err.message, 'erro');
    els.stats.innerHTML = vazio('alert', 'Não foi possível carregar os dados', 'Verifique se o servidor da cantina está ligado.');
  }
}

iniciar();

