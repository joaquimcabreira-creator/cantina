'use strict';

const http = require('node:http');
const fs = require('node:fs');
const fsp = fs.promises;
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const PIN = String(process.env.CANTINA_PIN || '1234');
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const LIMITE_CORPO = 100 * 1024;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json',
};

class HttpError extends Error {
  constructor(status, mensagem) {
    super(mensagem);
    this.status = status;
  }
}

let db = null;
let filaGravacao = Promise.resolve();

/* ------------------------------------------------------------------ */
/* Catálogo inicial da cantina                                         */
/* ------------------------------------------------------------------ */

const CATALOGO_INICIAL = [
  { nome: 'Pão de queijo', categoria: 'Salgados', preco: 4.5, unidade: 'un', minimo: 12, inicial: 46, vendidos: 6 },
  { nome: 'Coxinha de frango', categoria: 'Salgados', preco: 7.0, unidade: 'un', minimo: 10, inicial: 29, vendidos: 4 },
  { nome: 'Esfiha de carne', categoria: 'Salgados', preco: 6.5, unidade: 'un', minimo: 8, inicial: 20, vendidos: 2 },
  { nome: 'Pastel de queijo', categoria: 'Salgados', preco: 6.0, unidade: 'un', minimo: 8, inicial: 4, vendidos: 4 },
  { nome: 'Bolo de cenoura', categoria: 'Doces', preco: 5.0, unidade: 'fatia', minimo: 6, inicial: 18, vendidos: 6 },
  { nome: 'Bolo de chocolate', categoria: 'Doces', preco: 5.0, unidade: 'fatia', minimo: 6, inicial: 12, vendidos: 3 },
  { nome: 'Sanduíche natural', categoria: 'Lanches', preco: 8.0, unidade: 'un', minimo: 5, inicial: 10, vendidos: 3 },
  { nome: 'Misto quente', categoria: 'Lanches', preco: 7.5, unidade: 'un', minimo: 6, inicial: 18, vendidos: 3 },
  { nome: 'Suco de laranja 300ml', categoria: 'Bebidas', preco: 5.0, unidade: 'copo', minimo: 12, inicial: 36, vendidos: 6 },
  { nome: 'Suco de uva 300ml', categoria: 'Bebidas', preco: 5.0, unidade: 'copo', minimo: 12, inicial: 30, vendidos: 6 },
  { nome: 'Água mineral 500ml', categoria: 'Bebidas', preco: 3.0, unidade: 'garrafa', minimo: 20, inicial: 36, entrada: 24, vendidos: 12 },
  { nome: 'Refrigerante lata', categoria: 'Bebidas', preco: 6.0, unidade: 'lata', minimo: 12, inicial: 15, vendidos: 12 },
  { nome: 'Achocolatado 200ml', categoria: 'Bebidas', preco: 4.5, unidade: 'copo', minimo: 10, inicial: 26, vendidos: 6 },
  { nome: 'Iogurte natural', categoria: 'Saudável', preco: 4.0, unidade: 'pote', minimo: 8, inicial: 18, vendidos: 4 },
  { nome: 'Salada de frutas', categoria: 'Saudável', preco: 6.5, unidade: 'pote', minimo: 4, inicial: 10, vendidos: 4 },
  { nome: 'Brigadeiro', categoria: 'Doces', preco: 3.5, unidade: 'un', minimo: 15, inicial: 40, vendidos: 5 },
  { nome: 'Pipoca doce', categoria: 'Doces', preco: 3.0, unidade: 'pacote', minimo: 10, inicial: 10, vendidos: 0 },
  { nome: 'Biscoito integral', categoria: 'Saudável', preco: 2.5, unidade: 'pacote', minimo: 10, inicial: 28, vendidos: 6 },
  { nome: 'Chocolate ao leite', categoria: 'Doces', preco: 4.0, unidade: 'un', minimo: 10, inicial: 14, vendidos: 10 },
  { nome: 'Balas sortidas', categoria: 'Doces', preco: 2.0, unidade: 'pacote', minimo: 15, inicial: 25, entrada: 30, vendidos: 5 },
];

function bancoInicial() {
  const agora = new Date();
  const inicio = new Date(agora);
  inicio.setHours(0, 5, 0, 0);
  const quando = (horas) => {
    const t = Math.max(agora.getTime() - horas * 3600 * 1000, inicio.getTime());
    return new Date(Math.min(t, agora.getTime() - 60 * 1000)).toISOString();
  };

  const produtos = CATALOGO_INICIAL.map((item) => {
    const criado = quando(9);
    return {
      id: crypto.randomUUID(),
      nome: item.nome,
      categoria: item.categoria,
      preco: item.preco,
      unidade: item.unidade,
      estoqueMinimo: item.minimo,
      estoque: item.inicial,
      criadoEm: criado,
      atualizadoEm: criado,
    };
  });

  const pendentes = [];
  CATALOGO_INICIAL.forEach((item, i) => {
    if (item.entrada) {
      pendentes.push({ produto: produtos[i], tipo: 'entrada', quantidade: item.entrada, motivo: 'Compra de fornecedor', horas: 6.5 });
    }
    if (item.vendidos) {
      pendentes.push({
        produto: produtos[i],
        tipo: 'saida',
        quantidade: item.vendidos,
        motivo: 'Vendas do dia',
        horas: 0.8 + (i % 6) * 0.45,
      });
    }
  });

  // Aplica do mais antigo para o mais recente.
  pendentes.sort((a, b) => b.horas - a.horas);

  const movimentacoes = [];
  for (const mov of pendentes) {
    const p = mov.produto;
    if (mov.tipo === 'entrada') p.estoque += mov.quantidade;
    else p.estoque = Math.max(0, p.estoque - mov.quantidade);
    const data = quando(mov.horas);
    movimentacoes.push({
      id: crypto.randomUUID(),
      produtoId: p.id,
      produtoNome: p.nome,
      unidade: p.unidade,
      tipo: mov.tipo,
      quantidade: mov.quantidade,
      motivo: mov.motivo,
      precoUnitario: mov.tipo === 'saida' ? p.preco : undefined,
      estoqueApos: p.estoque,
      data,
    });
    p.atualizadoEm = data;
  }

  return { produtos, movimentacoes };
}

/* ------------------------------------------------------------------ */
/* Persistência                                                        */
/* ------------------------------------------------------------------ */

async function carregarBanco() {
  await fsp.mkdir(DATA_DIR, { recursive: true });
  try {
    const bruto = await fsp.readFile(DB_FILE, 'utf8');
    const dados = JSON.parse(bruto);
    db = {
      produtos: Array.isArray(dados.produtos) ? dados.produtos : [],
      movimentacoes: Array.isArray(dados.movimentacoes) ? dados.movimentacoes : [],
    };
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
    db = bancoInicial();
    await salvarBanco();
  }
}

function salvarBanco() {
  filaGravacao = filaGravacao
    .then(async () => {
      const temporario = `${DB_FILE}.tmp`;
      await fsp.writeFile(temporario, JSON.stringify(db, null, 2), 'utf8');
      await fsp.rename(temporario, DB_FILE);
    })
    .catch((err) => {
      console.error('Erro ao gravar os dados:', err);
    });
  return filaGravacao;
}

/* ------------------------------------------------------------------ */
/* Utilidades                                                          */
/* ------------------------------------------------------------------ */

function chaveDia(data) {
  const d = new Date(data);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function arredondar(valor, casas = 2) {
  const fator = 10 ** casas;
  return Math.round(valor * fator) / fator;
}

function pinValido(pin) {
  if (typeof pin !== 'string') return false;
  const a = Buffer.from(pin);
  const b = Buffer.from(PIN);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function exigirPin(req) {
  if (!pinValido(req.headers['x-cantina-pin'])) {
    throw new HttpError(401, 'Informe o PIN da cantina para alterar os dados.');
  }
}

function acharProduto(id) {
  const produto = db.produtos.find((p) => p.id === id);
  if (!produto) throw new HttpError(404, 'Produto não encontrado.');
  return produto;
}

function lerCorpo(req) {
  return new Promise((resolve, reject) => {
    let tamanho = 0;
    const partes = [];
    req.on('data', (parte) => {
      tamanho += parte.length;
      if (tamanho > LIMITE_CORPO) {
        reject(new HttpError(413, 'Dados enviados são muito grandes.'));
        req.destroy();
        return;
      }
      partes.push(parte);
    });
    req.on('end', () => {
      if (!partes.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(partes).toString('utf8')));
      } catch {
        reject(new HttpError(400, 'Dados inválidos.'));
      }
    });
    req.on('error', reject);
  });
}

function enviarJson(res, status, dados) {
  const corpo = JSON.stringify(dados);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(corpo),
  });
  res.end(corpo);
}

/* ------------------------------------------------------------------ */
/* Regras de negócio                                                   */
/* ------------------------------------------------------------------ */

function validarProduto(corpo) {
  const nome = String(corpo.nome || '').trim();
  if (!nome) throw new HttpError(400, 'Informe o nome do produto.');
  if (nome.length > 80) throw new HttpError(400, 'O nome pode ter no máximo 80 caracteres.');

  const categoria = (String(corpo.categoria || '').trim() || 'Geral').slice(0, 40);
  const unidade = (String(corpo.unidade || '').trim() || 'un').slice(0, 20);

  const preco = Number(corpo.preco);
  if (!Number.isFinite(preco) || preco < 0) throw new HttpError(400, 'Informe um preço válido.');

  const estoqueMinimo = Number(corpo.estoqueMinimo ?? 0);
  if (!Number.isFinite(estoqueMinimo) || estoqueMinimo < 0) {
    throw new HttpError(400, 'Informe um estoque mínimo válido.');
  }

  return {
    nome,
    categoria,
    unidade,
    preco: arredondar(preco),
    estoqueMinimo: Math.round(estoqueMinimo),
  };
}

function registrarMovimento(produto, tipo, quantidade, motivo, precoUnitario, data) {
  const qtd = arredondar(Number(quantidade), 3);
  if (tipo === 'entrada') produto.estoque = arredondar(produto.estoque + qtd, 3);
  else if (tipo === 'saida') produto.estoque = Math.max(0, arredondar(produto.estoque - qtd, 3));
  else produto.estoque = Math.max(0, qtd);

  const momento = data || new Date().toISOString();
  produto.atualizadoEm = momento;

  const movimentacao = {
    id: crypto.randomUUID(),
    produtoId: produto.id,
    produtoNome: produto.nome,
    unidade: produto.unidade,
    tipo,
    quantidade: qtd,
    motivo: String(motivo || '').trim().slice(0, 120),
    precoUnitario: tipo === 'saida' ? (precoUnitario ?? produto.preco) : undefined,
    estoqueApos: produto.estoque,
    data: momento,
  };
  db.movimentacoes.push(movimentacao);
  return movimentacao;
}

function calcularResumo() {
  const hoje = chaveDia(new Date());
  let valor = 0;
  let baixos = 0;
  let zerados = 0;

  for (const p of db.produtos) {
    valor += p.preco * p.estoque;
    if (p.estoque <= 0) zerados += 1;
    else if (p.estoque <= p.estoqueMinimo) baixos += 1;
  }

  let saidasHoje = 0;
  let entradasHoje = 0;
  let receitaHoje = 0;

  for (const m of db.movimentacoes) {
    if (chaveDia(m.data) !== hoje) continue;
    if (m.tipo === 'saida') {
      saidasHoje += m.quantidade;
      receitaHoje += m.quantidade * (m.precoUnitario || 0);
    } else if (m.tipo === 'entrada') {
      entradasHoje += m.quantidade;
    }
  }

  return {
    totalProdutos: db.produtos.length,
    valorEstoque: arredondar(valor),
    baixos,
    zerados,
    alertas: baixos + zerados,
    saidasHoje,
    entradasHoje,
    receitaHoje: arredondar(receitaHoje),
  };
}

function ordenarProdutos(lista) {
  return [...lista].sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
}

/* ------------------------------------------------------------------ */
/* API                                                                 */
/* ------------------------------------------------------------------ */

async function tratarApi(req, res, caminho, url) {
  if (req.method === 'GET' && caminho === '/api/estado') {
    const limite = Math.min(500, Math.max(1, Number(url.searchParams.get('limite')) || 200));
    return enviarJson(res, 200, {
      produtos: ordenarProdutos(db.produtos),
      movimentacoes: [...db.movimentacoes].sort((a, b) => b.data.localeCompare(a.data)).slice(0, limite),
      resumo: calcularResumo(),
      categorias: [...new Set(db.produtos.map((p) => p.categoria))].sort((a, b) => a.localeCompare(b, 'pt-BR')),
    });
  }

  if (req.method === 'POST' && caminho === '/api/login') {
    const corpo = await lerCorpo(req);
    if (!pinValido(corpo.pin)) throw new HttpError(401, 'PIN incorreto. Tente novamente.');
    return enviarJson(res, 200, { ok: true });
  }

  if (req.method === 'POST' && caminho === '/api/produtos') {
    exigirPin(req);
    const corpo = await lerCorpo(req);
    const dados = validarProduto(corpo);
    const estoqueInicial = Number(corpo.estoque ?? 0);
    if (!Number.isFinite(estoqueInicial) || estoqueInicial < 0) {
      throw new HttpError(400, 'Informe um estoque inicial válido.');
    }

    const agora = new Date().toISOString();
    const produto = {
      id: crypto.randomUUID(),
      ...dados,
      estoque: 0,
      criadoEm: agora,
      atualizadoEm: agora,
    };
    db.produtos.push(produto);

    if (estoqueInicial > 0) {
      registrarMovimento(produto, 'entrada', estoqueInicial, 'Estoque inicial');
    }

    await salvarBanco();
    return enviarJson(res, 201, produto);
  }

  const rotaProduto = caminho.match(/^\/api\/produtos\/([^/]+)$/);
  if (rotaProduto && req.method === 'PUT') {
    exigirPin(req);
    const produto = acharProduto(rotaProduto[1]);
    const dados = validarProduto(await lerCorpo(req));
    Object.assign(produto, dados, { atualizadoEm: new Date().toISOString() });
    await salvarBanco();
    return enviarJson(res, 200, produto);
  }

  if (rotaProduto && req.method === 'DELETE') {
    exigirPin(req);
    const produto = acharProduto(rotaProduto[1]);
    db.produtos = db.produtos.filter((p) => p.id !== produto.id);
    await salvarBanco();
    return enviarJson(res, 200, { ok: true });
  }

  const rotaMovimentacao = caminho.match(/^\/api\/produtos\/([^/]+)\/movimentacoes$/);
  if (rotaMovimentacao && req.method === 'POST') {
    exigirPin(req);
    const produto = acharProduto(rotaMovimentacao[1]);
    const corpo = await lerCorpo(req);

    const tipo = corpo.tipo;
    if (!['entrada', 'saida', 'ajuste'].includes(tipo)) {
      throw new HttpError(400, 'Tipo de movimentação inválido.');
    }

    const quantidade = Number(corpo.quantidade);
    if (!Number.isFinite(quantidade) || quantidade < 0) {
      throw new HttpError(400, 'Informe uma quantidade válida.');
    }
    if (tipo !== 'ajuste' && quantidade <= 0) {
      throw new HttpError(400, 'A quantidade precisa ser maior que zero.');
    }
    if (tipo === 'saida' && quantidade > produto.estoque) {
      throw new HttpError(400, `Estoque insuficiente. Disponível: ${produto.estoque} ${produto.unidade}.`);
    }

    const movimentacao = registrarMovimento(produto, tipo, quantidade, corpo.motivo);
    await salvarBanco();
    return enviarJson(res, 201, movimentacao);
  }

  throw new HttpError(404, 'Rota não encontrada.');
}

/* ------------------------------------------------------------------ */
/* Arquivos estáticos                                                  */
/* ------------------------------------------------------------------ */

async function servirEstatico(res, caminho) {
  const relativo = caminho === '/' ? 'index.html' : caminho.replace(/^\/+/, '');
  const arquivo = path.normalize(path.join(PUBLIC_DIR, relativo));

  if (!arquivo.toLowerCase().startsWith(PUBLIC_DIR.toLowerCase() + path.sep)) {
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Acesso negado.');
  }

  try {
    const conteudo = await fsp.readFile(arquivo);
    const tipo = MIME[path.extname(arquivo).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': tipo,
      'Cache-Control': 'no-cache',
      'Content-Length': conteudo.length,
    });
    res.end(conteudo);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Arquivo não encontrado.');
  }
}

/* ------------------------------------------------------------------ */
/* Servidor                                                            */
/* ------------------------------------------------------------------ */

const servidor = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  let caminho;
  try {
    caminho = decodeURIComponent(url.pathname);
  } catch {
    res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Endereço inválido.');
  }

  try {
    if (caminho.startsWith('/api/')) {
      await tratarApi(req, res, caminho, url);
    } else {
      await servirEstatico(res, caminho);
    }
  } catch (err) {
    if (res.headersSent) return res.end();
    const status = err instanceof HttpError ? err.status : 500;
    if (status === 500) console.error(err);
    enviarJson(res, status, { erro: err.message || 'Erro interno no servidor.' });
  }
});

function enderecosDaLan() {
  const lista = [];
  for (const interfaces of Object.values(os.networkInterfaces())) {
    for (const item of interfaces || []) {
      if (item.family === 'IPv4' && !item.internal) lista.push(item.address);
    }
  }
  return lista;
}

carregarBanco()
  .then(() => {
    servidor.listen(PORT, HOST, () => {
      console.log('');
      console.log('  Cantina Presidente Kennedy');
      console.log('  --------------------------------');
      console.log(`  Neste computador: http://localhost:${PORT}`);
      for (const ip of enderecosDaLan()) {
        console.log(`  Na rede local:    http://${ip}:${PORT}`);
      }
      console.log(`  PIN de acesso:    ${PIN}`);
      console.log('');
      console.log('  Dados salvos em data/db.json');
      console.log('  Para encerrar, pressione Ctrl+C');
      console.log('');
    });
  })
  .catch((err) => {
    console.error('Não foi possível iniciar o servidor:', err);
    process.exit(1);
  });

process.on('SIGINT', () => {
  servidor.close(() => process.exit(0));
});
