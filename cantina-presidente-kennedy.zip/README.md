# Cantina Presidente Kennedy

Sistema web de **controle de estoque e produtos** da cantina do Colégio Presidente Kennedy.
Roda em um servidor Node.js simples, sem instalar bibliotecas, e pode ser acessado por vários
aparelhos ao mesmo tempo (computador, tablet e celular).

## O que o app faz

- **Painel** com produtos cadastrados, itens em alerta, valor do estoque e saídas do dia.
- **Produtos** com busca, filtro por categoria/status, preço, unidade, estoque mínimo e barra de nível.
- **Movimentações** de entrada, saída (venda) e ajuste de contagem, com motivo e histórico.
- **Alertas** de estoque baixo ou em falta, com botão de reposição rápida.
- **Exportação em CSV** (abre no Excel) da lista de produtos.
- **PIN de acesso** para proteger alterações. O PIN fica salvo em cada aparelho.
- Atualização automática dos dados a cada 25 segundos, para vários aparelhos verem o mesmo estoque.

## Como rodar no computador da cantina

1. Instale o [Node.js](https://nodejs.org) (versão 18 ou superior).
2. Dê dois cliques em **`iniciar-cantina.bat`**.
   Ou abra o terminal nesta pasta e execute:
   ```
   npm start
   ```
3. O navegador abre em `http://localhost:3000`.

## Acessar de outros aparelhos (mesma rede Wi-Fi)

Quando o servidor inicia, o terminal mostra um endereço parecido com:

```
Na rede local: http://192.168.0.10:3000
```

Digite esse endereço no navegador do celular ou de outro computador conectado à mesma rede.
Se não abrir, libere o Node.js no Firewall do Windows (na primeira execução o Windows pergunta)
e confirme que todos os aparelhos estão na mesma rede.

## PIN de acesso

- PIN padrão: **1234**
- Para trocar, defina a variável de ambiente `CANTINA_PIN` antes de iniciar:

  ```bat
  set CANTINA_PIN=4321
  node server.js
  ```

- Ao cadastrar o primeiro produto, o app pede o PIN e o guarda no aparelho.
- O botão de cadeado no topo permite trocar ou esquecer o PIN.

## Onde ficam os dados

Tudo é salvo em **`data/db.json`**. Para fazer backup, copie esse arquivo.
Para começar do zero, apague-o e reinicie o servidor (o catálogo de exemplo é recriado).

## Acessar pela internet (opcional)

O projeto não tem dependências externas, então funciona em qualquer serviço de hospedagem Node.js
(Render, Railway, Fly.io, VPS etc.):

- Comando de start: `npm start`
- O serviço define a porta pela variável `PORT` automaticamente.
- Configure `CANTINA_PIN` com um PIN forte.
- Em hospedagens gratuitas o disco pode ser temporário; para uso definitivo, use um plano com disco
  persistente ou monte um volume em `/data`.

## Estrutura

```
server.js                 servidor HTTP + API + persistência em JSON
public/index.html         interface
public/styles.css         estilos
public/app.js             lógica da interface
public/icon.svg           ícone do app
public/manifest.webmanifest
data/db.json              dados (criado automaticamente)
iniciar-cantina.bat       atalho para Windows
```

## Dicas de uso no dia a dia

- Use o botão **Saída** para registrar vendas e **Entrada** ao receber mercadoria.
- Use **Ajuste** para corrigir a contagem depois de um inventário.
- Defina um **estoque mínimo** realista: o painel avisa antes de acabar.
- Exporte a planilha no fim do mês para conferência.
